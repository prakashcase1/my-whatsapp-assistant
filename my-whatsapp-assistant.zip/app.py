"""
Missed-Call Lead Assistant: Meta WhatsApp Cloud API + Anthropic Claude (no Twilio)
----------------------------------------------------------------------------------
Endpoints
  GET  /webhook      Meta verification handshake (hub.mode / hub.verify_token / hub.challenge)
  POST /webhook      Inbound WhatsApp messages -> Claude -> reply -> SQLite -> CRM
  POST /missed-call  Trigger for the opening message. Call it from whatever sees your missed calls
                     (Make/Zapier, your VoIP provider's webhook, a call-log forwarder). Header: X-Api-Key
  GET  /health

Why /missed-call exists: WhatsApp Cloud API cannot see ordinary phone calls. Twilio used to do that,
so something else now has to tell this server "caller X was missed".

Run:  gunicorn -w 2 -b 0.0.0.0:8000 app:app
"""
import hashlib
import hmac
import json
import logging
import os
import re
import sqlite3
import time
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager

import anthropic
import requests
from dotenv import load_dotenv
from flask import Flask, Response, abort, jsonify, request

load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("wa-assistant")


# ================================================================ configuration
def env(name, default=""):
    return os.getenv(name, default).strip()


def require(name):
    value = env(name)
    if not value:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value


WHATSAPP_TOKEN = require("WHATSAPP_TOKEN")        # System User access token (permanent)
PHONE_NUMBER_ID = require("PHONE_NUMBER_ID")      # WhatsApp phone number ID (not the phone number)
VERIFY_TOKEN = require("VERIFY_TOKEN")            # any secret string you also type into the Meta dashboard
require("ANTHROPIC_API_KEY")                      # read by the Anthropic SDK itself

# Meta signs every webhook POST with your App Secret. Strongly recommended in production.
APP_SECRET = env("APP_SECRET")
# Shared secret for POST /missed-call. The endpoint stays disabled until you set it.
MISSED_CALL_SECRET = env("MISSED_CALL_SECRET")

# Graph API versions expire after ~2 years. Keep this configurable and bump it from time to time.
GRAPH_API_VERSION = env("GRAPH_API_VERSION", "v25.0")
GRAPH_URL = f"https://graph.facebook.com/{GRAPH_API_VERSION}/{PHONE_NUMBER_ID}/messages"

# Business-initiated messages (the missed-call opener) must be an approved template.
# Template body should read: "Hi, this is {{1}}. Sorry we missed your call! ..." (see GREETING below)
TEMPLATE_NAME = env("WHATSAPP_TEMPLATE_NAME")
TEMPLATE_LANG = env("WHATSAPP_TEMPLATE_LANG", "en_GB")

CLAUDE_MODEL = env("CLAUDE_MODEL", "claude-haiku-4-5-20251001")
CRM_WEBHOOK_URL = env("CRM_WEBHOOK_URL")
DB_PATH = env("DB_PATH", "leads.db")
DEFAULT_COUNTRY_CODE = env("DEFAULT_COUNTRY_CODE", "44")  # turns UK-style 07... into 447...

BIZ = {
    "business_name": env("BUSINESS_NAME", "Bright Smile Dental"),
    "business_type": env("BUSINESS_TYPE", "dental clinic"),
    "services": env("SERVICES", "checkups, cleaning, whitening, fillings, emergency visits"),
    "hours": env("HOURS", "Mon-Fri 9am-6pm, Sat 9am-1pm"),
    "booking_link": env("BOOKING_LINK", "none"),
    "emergency_examples": env("EMERGENCY_EXAMPLES", "severe pain, facial swelling, knocked-out tooth, heavy bleeding"),
    "owner_phone": env("OWNER_PHONE"),
}

# If you use a template, its approved wording must match this text, because this is what we
# save to the thread so Claude knows what the customer actually saw.
GREETING = (
    f"Hi, this is {BIZ['business_name']}. Sorry we missed your call! "
    "What can we help you with? Reply here and we'll get you sorted."
)

TEXTBACK_COOLDOWN_SECONDS = 600       # never open twice within 10 minutes
MAX_REPLY_CHARS = 1000                # WhatsApp allows 4096; the prompt keeps replies far shorter
STOP_WORDS = {"STOP", "STOPALL", "UNSUBSCRIBE", "CANCEL", "END", "QUIT"}
CRM_PUSH_STATUSES = {"ready_to_confirm", "urgent", "needs_human", "opted_out"}
OWNER_ALERT_STATUSES = {"ready_to_confirm", "urgent", "needs_human"}

SYSTEM_PROMPT = """You are the WhatsApp assistant for {{business_name}}, a {{business_type}}. You are chatting with a customer in the UK who just called and didn't get through. Your job is to find out what they need, get their name, and pin down a time that works for them. A real person on the team confirms every booking.

About the business
- Services: {{services}}
- Hours: {{hours}}
- Booking link (share only if they ask for it): {{booking_link}}

How to write
- Sound like a friendly front-desk person. Plain words, no corporate phrasing, no emojis unless the customer uses them first.
- Use British English and UK date/time style (for example "Thursday 4pm").
- Keep every reply under 320 characters. One idea per message.
- Ask one question at a time. Never ask for the need, the name, and the time in the same message.
- Use their first name once you know it, not in every message.

What to collect, in this order
1. What they need help with
2. Their first name
3. Preferred day and time (two options is ideal)
When you have all three, repeat them back in one sentence, say a team member will confirm shortly, and stop asking questions.

Rules
- Never quote prices, promise availability, or give medical, legal, or safety advice. If asked about price, say pricing depends on the details and the team will go over it when they confirm.
- Emergencies ({{emergency_examples}}): drop the booking flow, tell them to call {{owner_phone}} right now, and set status to "urgent". If there is any danger to life, tell them to call 999 first.
- If they ask whether you're a bot, say yes: you're the business's automated assistant and a real person will follow up.
- If they say stop, unsubscribe, or not interested, apologise once, say you won't message again, and set status to "opted_out".
- If a message is unclear or off topic, ask one short clarifying question. Don't guess.
- Never invent details about the business. If you don't know, say the team will follow up.

Output format
Return only valid JSON. No markdown fences, no extra text.
{"reply": "...", "name": "", "service": "", "preferred_time": "", "status": "collecting"}
Allowed status values: collecting, ready_to_confirm, urgent, opted_out.
Fill in fields as you learn them. Keep earlier values. Leave unknown ones as "".
"""

if not APP_SECRET:
    log.warning("APP_SECRET is not set: webhook signatures are NOT being verified. Set it before going live.")

app = Flask(__name__)
claude = anthropic.Anthropic()
executor = ThreadPoolExecutor(max_workers=8)  # webhook returns 200 fast; real work runs here


# ================================================================ phone numbers
def normalize_phone(raw):
    """Anything -> digits only, international format without '+': '07123 456789' -> '447123456789'.
    Meta sends and accepts numbers in this form, and it is the only form stored in SQLite."""
    digits = re.sub(r"\D", "", str(raw or ""))
    if digits.startswith("00"):
        digits = digits[2:]
    elif digits.startswith("0") and DEFAULT_COUNTRY_CODE:
        digits = DEFAULT_COUNTRY_CODE + digits[1:]
    return digits


def display_phone(phone):
    return "+" + phone


# ================================================================ database (SQLite, WAL, timeout=15)
@contextmanager
def db():
    conn = sqlite3.connect(DB_PATH, timeout=15)  # wait up to 15s on a lock instead of erroring
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    with db() as c:
        c.execute("PRAGMA journal_mode=WAL")  # readers and writers don't block each other
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                phone TEXT, role TEXT, content TEXT, ts REAL
            );
            CREATE INDEX IF NOT EXISTS idx_messages_phone ON messages (phone, id);
            CREATE TABLE IF NOT EXISTS leads (
                phone TEXT PRIMARY KEY,
                name TEXT DEFAULT '', service TEXT DEFAULT '',
                preferred_time TEXT DEFAULT '', status TEXT DEFAULT 'new',
                last_textback REAL DEFAULT 0, updated REAL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS processed (   -- Meta retries webhooks; dedupe on message id
                wamid TEXT PRIMARY KEY, ts REAL
            );
            """
        )
        c.execute("DELETE FROM processed WHERE ts < ?", (time.time() - 7 * 86400,))


def claim_message(wamid):
    """True the first time we see this message id, False on a Meta retry (atomic across workers)."""
    with db() as c:
        cur = c.execute("INSERT OR IGNORE INTO processed (wamid, ts) VALUES (?, ?)", (wamid, time.time()))
        return cur.rowcount == 1


def get_lead(phone):
    with db() as c:
        row = c.execute("SELECT * FROM leads WHERE phone = ?", (phone,)).fetchone()
    return dict(row) if row else None


def upsert_lead(phone, **fields):
    fields["updated"] = time.time()
    with db() as c:
        c.execute("INSERT OR IGNORE INTO leads (phone) VALUES (?)", (phone,))
        sets = ", ".join(f"{k} = ?" for k in fields)
        c.execute(f"UPDATE leads SET {sets} WHERE phone = ?", (*fields.values(), phone))


def save_message(phone, role, content):
    with db() as c:
        c.execute(
            "INSERT INTO messages (phone, role, content, ts) VALUES (?, ?, ?, ?)",
            (phone, role, content, time.time()),
        )


def build_messages(phone, limit=20):
    """Claude needs alternating roles starting with 'user', so merge repeats and drop a leading assistant turn."""
    with db() as c:
        rows = c.execute(
            "SELECT role, content FROM messages WHERE phone = ? ORDER BY id DESC LIMIT ?", (phone, limit)
        ).fetchall()
    merged = []
    for row in reversed(rows):
        if merged and merged[-1]["role"] == row["role"]:
            merged[-1]["content"] += "\n" + row["content"]
        else:
            merged.append({"role": row["role"], "content": row["content"]})
    while merged and merged[0]["role"] != "user":
        merged.pop(0)
    return merged


# ================================================================ WhatsApp Cloud API
def _post_to_meta(payload):
    """POST to the Graph API. Returns the parsed JSON on success, None on failure (and logs why).
    Useful error codes: 131047 = outside the 24h window (needs a template), 131026 = number not on
    WhatsApp, 132001 = template name/language not found, 190 = bad or expired token."""
    headers = {"Authorization": f"Bearer {WHATSAPP_TOKEN}", "Content-Type": "application/json"}
    try:
        resp = requests.post(GRAPH_URL, headers=headers, json=payload, timeout=15)
    except requests.RequestException:
        log.exception("Could not reach the Graph API")
        return None
    try:
        data = resp.json()
    except ValueError:
        data = {}
    if resp.status_code >= 400:
        err = data.get("error", {})
        log.error("WhatsApp API error %s: code=%s message=%s", resp.status_code, err.get("code"), err.get("message"))
        return None
    return data


def send_whatsapp_message(to_phone, message_text):
    """Free-form text. Only delivered inside the 24h window that opens when the customer messages you."""
    payload = {
        "messaging_product": "whatsapp",
        "recipient_type": "individual",
        "to": normalize_phone(to_phone),
        "type": "text",
        "text": {"preview_url": False, "body": message_text[:MAX_REPLY_CHARS]},
    }
    return _post_to_meta(payload) is not None


def send_template_message(to_phone):
    """Approved template with {{1}} = business name. Required to open a conversation."""
    payload = {
        "messaging_product": "whatsapp",
        "to": normalize_phone(to_phone),
        "type": "template",
        "template": {
            "name": TEMPLATE_NAME,
            "language": {"code": TEMPLATE_LANG},
            "components": [{"type": "body", "parameters": [{"type": "text", "text": BIZ["business_name"]}]}],
        },
    }
    return _post_to_meta(payload) is not None


def mark_as_read(wamid):
    _post_to_meta({"messaging_product": "whatsapp", "status": "read", "message_id": wamid})


# ================================================================ Claude
def build_system_prompt():
    prompt = SYSTEM_PROMPT
    for key, value in BIZ.items():
        prompt = prompt.replace("{{" + key + "}}", value)
    return prompt + f'\n\nThe customer already received this message from you: "{GREETING}"'


def parse_json(text):
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1:
        raise ValueError("no JSON in model output")
    return json.loads(text[start : end + 1])


def run_assistant(phone):
    try:
        resp = claude.messages.create(
            model=CLAUDE_MODEL, max_tokens=400, system=build_system_prompt(), messages=build_messages(phone)
        )
        return parse_json(resp.content[0].text)
    except Exception:
        log.exception("Claude call failed")
        return {"reply": "Thanks for your message! A team member will get back to you shortly.", "status": "needs_human"}


# ================================================================ CRM + owner alerts
def push_crm(phone, event, lead=None):
    if not CRM_WEBHOOK_URL:
        return
    lead = lead or get_lead(phone) or {}
    payload = {
        "event": event,
        "business": BIZ["business_name"],
        "phone": display_phone(phone),
        "channel": "whatsapp",
        "name": lead.get("name", ""),
        "service": lead.get("service", ""),
        "preferred_time": lead.get("preferred_time", ""),
        "status": lead.get("status", ""),
        "source": "missed_call_whatsapp",
        "timestamp": int(time.time()),
    }
    try:
        requests.post(CRM_WEBHOOK_URL, json=payload, timeout=8).raise_for_status()
    except requests.RequestException:
        log.exception("CRM push failed")


def notify_owner(text):
    """Best effort. A free-form WhatsApp to the owner only lands if they messaged this number in the last
    24h, so treat the CRM webhook (email/Slack from Make) as the reliable alert channel."""
    if BIZ["owner_phone"]:
        send_whatsapp_message(BIZ["owner_phone"], text)


# ================================================================ core logic
def start_conversation(phone):
    """Send the missed-call opener. Returns (ok, reason)."""
    lead = get_lead(phone)
    if lead and lead["status"] == "opted_out":
        return False, "opted_out"
    if lead and time.time() - lead["last_textback"] < TEXTBACK_COOLDOWN_SECONDS:
        return False, "cooldown"

    sent = send_template_message(phone) if TEMPLATE_NAME else send_whatsapp_message(phone, GREETING)
    if not sent:
        return False, "send_failed"

    save_message(phone, "assistant", GREETING)
    upsert_lead(phone, status="textback_sent", last_textback=time.time())
    push_crm(phone, "missed_call")
    return True, "sent"


def extract_text(msg):
    kind = msg.get("type")
    if kind == "text":
        return msg.get("text", {}).get("body", "")
    if kind == "button":  # quick-reply button on a template
        return msg.get("button", {}).get("text", "")
    if kind == "interactive":
        inter = msg.get("interactive", {})
        return (inter.get("button_reply") or inter.get("list_reply") or {}).get("title", "")
    return ""  # audio, image, sticker, location, etc.


def process_message(msg):
    """Handle one inbound WhatsApp message (runs in the thread pool)."""
    wamid, sender = msg.get("id"), normalize_phone(msg.get("from"))
    if not wamid or not sender or not claim_message(wamid):
        return  # malformed, or a Meta retry we've already handled

    mark_as_read(wamid)
    body = extract_text(msg).strip()

    if not body:
        send_whatsapp_message(sender, "Thanks! I can only read text messages here. Could you type that out for me?")
        return

    if body.upper() in STOP_WORDS:
        upsert_lead(sender, status="opted_out")
        push_crm(sender, "opted_out")
        send_whatsapp_message(sender, "Understood, we won't message you again. Sorry to have bothered you.")
        return

    previous = get_lead(sender) or {}
    save_message(sender, "user", body)
    result = run_assistant(sender)

    reply = (result.get("reply") or "Thanks! A team member will follow up shortly.")[:MAX_REPLY_CHARS]
    save_message(sender, "assistant", reply)

    updates = {"status": result.get("status") or previous.get("status", "collecting")}
    for field in ("name", "service", "preferred_time"):
        value = (result.get(field) or "").strip()
        if value:  # never overwrite known info with blanks
            updates[field] = value
    upsert_lead(sender, **updates)
    lead = get_lead(sender)

    send_whatsapp_message(sender, reply)

    if updates["status"] != previous.get("status"):
        if updates["status"] in CRM_PUSH_STATUSES:
            push_crm(sender, "lead_updated", lead)
        if updates["status"] in OWNER_ALERT_STATUSES:
            notify_owner(
                f"[{updates['status'].upper()}] {lead['name'] or 'Unknown'} {display_phone(sender)} | "
                f"{lead['service'] or '?'} | {lead['preferred_time'] or '?'}"
            )


def safe_process(msg):
    try:
        process_message(msg)
    except Exception:
        log.exception("Unhandled error while processing message %s", msg.get("id"))


# ================================================================ routes
def valid_signature(raw_body, header):
    if not APP_SECRET:
        return True
    expected = "sha256=" + hmac.new(APP_SECRET.encode(), raw_body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, header or "")


@app.get("/health")
def health():
    return {"ok": True}


@app.get("/webhook")
def verify_webhook():
    """Meta's one-time handshake when you click 'Verify and save' in the dashboard."""
    mode = request.args.get("hub.mode")
    token = request.args.get("hub.verify_token", "")
    challenge = request.args.get("hub.challenge", "")
    if mode == "subscribe" and hmac.compare_digest(token, VERIFY_TOKEN):
        return Response(challenge, status=200, mimetype="text/plain")
    return Response("Forbidden", status=403)


@app.post("/webhook")
def receive_webhook():
    """Inbound messages and delivery statuses. Always answer 200 quickly; Meta retries on slow/failed responses."""
    raw = request.get_data()
    if not valid_signature(raw, request.headers.get("X-Hub-Signature-256")):
        abort(403)

    payload = request.get_json(force=True, silent=True) or {}  # parse even if the content-type header is odd
    for entry in payload.get("entry", []):
        for change in entry.get("changes", []):
            value = change.get("value", {})
            if value.get("metadata", {}).get("phone_number_id") not in (None, PHONE_NUMBER_ID):
                continue  # event for a different number on the same app
            for msg in value.get("messages", []):  # absent for pure status updates (sent/delivered/read)
                executor.submit(safe_process, msg)
    return Response("EVENT_RECEIVED", status=200)


@app.post("/missed-call")
def missed_call():
    """Body: {"phone": "+447123456789"} (07... works too). Header: X-Api-Key: <MISSED_CALL_SECRET>."""
    if not MISSED_CALL_SECRET:
        return jsonify(error="endpoint disabled: set MISSED_CALL_SECRET"), 503
    if not hmac.compare_digest(request.headers.get("X-Api-Key", ""), MISSED_CALL_SECRET):
        abort(401)

    phone = normalize_phone((request.get_json(silent=True) or {}).get("phone"))
    if not 8 <= len(phone) <= 15:
        return jsonify(error="invalid phone number"), 400

    ok, reason = start_conversation(phone)
    if ok:
        return jsonify(status="sent")
    if reason == "send_failed":
        return jsonify(status="failed", hint="check logs: usually missing/unapproved template (132001) or no WhatsApp"), 502
    return jsonify(status="skipped", reason=reason)


init_db()

if __name__ == "__main__":
    app.run(port=int(env("PORT", "5000")), debug=True)
